const db = require('../../Models');
const axios = require('axios');

const { uploadFiles, requeueAsset } = require('../../Helper/MediaService');
const {
    enrichMediaList,
    addTokenToUrl,
    getSecureImageUrl,
    getSecureStreamUrl
} = require('../../Helper/mediaHelper');

const { parseOrArray } = require('../../Helper/parseOrArray');
const { emitReferralActivated } = require('../../Helper/PartnersWebhookService');
const User = db.users;
const becomeCreator = db.become_creator_request;

// ============================================================
// Helpers
// ============================================================

const CREATOR_STATUSES = new Set([
    'new',
    'student',
    'established',
    'premium'
]);

function normalizeCreatorStatus(value) {
    const status = String(value || 'new').toLowerCase().trim();
    return CREATOR_STATUSES.has(status) ? status : 'new';
}

async function ensureCreatorProfile(userId, defaults = {}) {
    const [creatorProfile] = await becomeCreator.findOrCreate({
        where: { userId },
        defaults: {
            userId,
            creator_status: normalizeCreatorStatus(defaults.creator_status)
        }
    });

    return creatorProfile;
}

async function getCreatorProfileRow(userId) {
    return await becomeCreator.findOne({
        where: { userId }
    });
}

const VISIBLE_MEDIA_STATUSES = new Set([
    'SAFE',
    'SUGGESTIVE',
    'EXPLICIT',
    'APPROVED',
    'COMPLETED'
]);

function normalizeStatus(status, fallback = 'PENDING') {
    return String(status || fallback).toUpperCase();
}

function canShowUrl(status) {
    return VISIBLE_MEDIA_STATUSES.has(normalizeStatus(status));
}


const MAX_FAVOURITE_MEDIA = 5;

const BAD_FAVOURITE_MEDIA_STATUSES = new Set([
    'FAILED',
    'ERROR',
    'REJECTED',
    'REJECTED_BY_AI',
    'REQUIRES_TAGGING',
    'BLOCKED',
    'BLOCKED_FACES',
    'DELETED',
    'DELETED_BY_USER'
]);

function isBadFavouriteMediaStatus(status) {
    return BAD_FAVOURITE_MEDIA_STATUSES.has(normalizeStatus(status));
}

function trimFavouritePicsForStorage(items = []) {
    const cleanItems = (items || [])
        .filter(item => item && item.media_id)
        .filter(item => !isBadFavouriteMediaStatus(
            item.status ||
            item.moderation_status
        ));

    const visibleItems = cleanItems.filter(item =>
        canShowUrl(item.status || item.moderation_status || item.content_rating)
    );

    if (visibleItems.length <= MAX_FAVOURITE_MEDIA) {
        return cleanItems;
    }

    const removeCount = visibleItems.length - MAX_FAVOURITE_MEDIA;

    const removeIds = new Set(
        visibleItems
            .slice(0, removeCount)
            .map(item => item.media_id)
    );

    return cleanItems.filter(item => !removeIds.has(item.media_id));
}

function normalizeBoolean(value) {
    return (
        value === true ||
        value === 1 ||
        value === '1' ||
        String(value || '').toLowerCase() === 'true' ||
        String(value || '').toLowerCase() === 'yes'
    );
}

function parsePositiveInt(value, fallback = 0) {
    const parsed = parseInt(value, 10);

    if (!Number.isFinite(parsed) || Number.isNaN(parsed) || parsed < 0) {
        return fallback;
    }

    return parsed;
}

function getFavouriteVideoTiming(body = {}) {
    // Backend-only safe fallback:
    // Frontend duration na bheje to 0 rakho. Video worker ffprobe se real duration nikaal lega.
    const durationS = parsePositiveInt(
        body.duration_s ||
        body.duration ||
        body.video_duration_s ||
        body.media_duration_s,
        0
    );

    const hasPreview = normalizeBoolean(body.has_preview);

    const previewStart = parsePositiveInt(
        body.preview_start ||
        body.previewStart,
        0
    );

    let previewEnd = parsePositiveInt(
        body.preview_end ||
        body.previewEnd,
        30
    );

    if (previewEnd <= previewStart) {
        previewEnd = previewStart + 30;
    }

    return {
        durationS,
        hasPreview,
        previewStart,
        previewEnd
    };
}

function looksLikeMediaId(value) {
    return typeof value === 'string' && value.startsWith('img_');
}

function extractMediaIdFromValue(value) {
    if (!value) return null;

    const match = String(value).match(/img_[a-zA-Z0-9-]+/);
    return match ? match[0] : null;
}

function buildSignedImageUrlFromMediaId(mediaId) {
    if (!mediaId) return null;
    return getSecureImageUrl(`images/${mediaId}.webp`);
}

function formatMediaObject(media = {}, fallback = {}) {
    const status = normalizeStatus(
        media.status ||
        media.moderation_status ||
        fallback.status,
        'PENDING'
    );

    const contentRating = normalizeStatus(
        media.content_rating ||
        media.preview_status ||
        fallback.contentRating ||
        status,
        status
    );

    const mediaType = String(
        media.type ||
        fallback.type ||
        'image'
    ).toLowerCase();

    const blockedStatus = new Set([
        'FAILED',
        'ERROR',
        'PROCESSING',
        'PENDING',
        'REJECTED',
        'REJECTED_BY_AI',
        'BLOCKED',
        'DELETED',
        'DELETED_BY_USER'
    ]);

    const viewable =
        !blockedStatus.has(status) &&
        (canShowUrl(status) || canShowUrl(contentRating));

    const mediaId =
        media.media_id ||
        fallback.mediaId ||
        (looksLikeMediaId(fallback.dbUrl) ? fallback.dbUrl : null);

    // VIDEO ko image-token helper se pass nahi karna.
    if (mediaType === 'video') {
        const videoUrl =
            media.bunny_video_id
                ? getSecureStreamUrl(media.bunny_video_id)
                : (media.url || null);

        return {
            media_id: mediaId,
            type: 'video',
            bunny_video_id: media.bunny_video_id || null,

            status,
            moderation_status: normalizeStatus(
                media.moderation_status || fallback.moderationStatus || status,
                status
            ),
            content_rating: contentRating,
            preview_status: media.preview_status || status,

            url: viewable ? videoUrl : null,
            preview_url: viewable ? (media.preview_url || null) : null,

            moderation_tags: media.moderation_tags || media.tags || fallback.moderation_tags || [],
            rejection_reason: media.rejection_reason || fallback.rejection_reason || null,
            faces_detected: media.faces_detected || fallback.faces_detected || 0,
            has_preview: media.has_preview || false
        };
    }

    let sourceUrl =
        media.url ||
        fallback.dbUrl ||
        null;

    // Agar DB me img_xxx save hai, usko URL na samjho; signed URL banao
    if (looksLikeMediaId(sourceUrl)) {
        sourceUrl = buildSignedImageUrlFromMediaId(sourceUrl);
    }

    let sourcePreviewUrl =
        media.preview_url ||
        sourceUrl;

    if (looksLikeMediaId(sourcePreviewUrl)) {
        sourcePreviewUrl = buildSignedImageUrlFromMediaId(sourcePreviewUrl);
    }

    const signedUrl = sourceUrl && viewable
        ? addTokenToUrl(sourceUrl)
        : null;

    const signedPreviewUrl = sourcePreviewUrl && viewable
        ? addTokenToUrl(sourcePreviewUrl)
        : signedUrl;

    return {
        media_id: mediaId,
        type: 'image',
        bunny_video_id: null,

        status,
        moderation_status: normalizeStatus(
            media.moderation_status || fallback.moderationStatus || status,
            status
        ),
        content_rating: contentRating,
        preview_status: media.preview_status || status,

        url: viewable
            ? addTokenToUrl(media.url || signedUrl)
            : null,

        preview_url: viewable
            ? addTokenToUrl(media.preview_url || signedPreviewUrl || media.url || signedUrl)
            : null,

        moderation_tags: media.moderation_tags || media.tags || fallback.moderation_tags || [],
        rejection_reason: media.rejection_reason || fallback.rejection_reason || null,
        faces_detected: media.faces_detected || fallback.faces_detected || 0,
        has_preview: media.has_preview || false
    };
}

async function buildCreatorMedia({ mediaId, dbUrl, status, contentRating }) {
    if (!mediaId && !dbUrl) return null;

    const fallbackStatus = normalizeStatus(status, 'PENDING');
    const fallbackContentRating = normalizeStatus(
        contentRating || fallbackStatus,
        fallbackStatus
    );

    let enriched = null;

    if (mediaId) {
        const result = await enrichMediaList([
            {
                media_id: mediaId,
                type: 'image',
                status: fallbackStatus,
                context: 'CREATOR'
            }
        ]);

        enriched = result[0] || null;
    }

    const formatted = formatMediaObject(enriched || {}, {
        mediaId,
        dbUrl,
        status: fallbackStatus,
        moderationStatus: fallbackStatus,
        contentRating: fallbackContentRating,
        type: 'image'
    });

    // Agar Dynamo/Canonical se URL nahi mila, DB ke base URL se signed URL banao
    if (
        !formatted.url &&
        dbUrl &&
        (canShowUrl(formatted.status) || canShowUrl(formatted.content_rating))
    ) {
        const signedUrl = addTokenToUrl(dbUrl);
        formatted.url = signedUrl;
        formatted.preview_url = signedUrl;
    }

    return formatted;
}

async function buildFavouritePics(rawFavouritePics) {
    const rawFavPics = parseOrArray(rawFavouritePics) || [];

    if (!rawFavPics.length) return [];

    const enrichedFavPics = await enrichMediaList(rawFavPics);

    return enrichedFavPics
        .map((item, index) => {
            const original = rawFavPics[index] || {};

            return formatMediaObject(item, {
                mediaId: item.media_id || original.media_id,
                dbUrl: item.url || original.url,
                status: item.status || original.status || 'PENDING',
                moderationStatus:
                    item.moderation_status ||
                    original.moderation_status ||
                    item.status ||
                    original.status,
                contentRating:
                    item.content_rating ||
                    original.content_rating ||
                    item.status ||
                    original.status,
                type: item.type || original.type || 'image',
                moderation_tags: item.moderation_tags || original.moderation_tags || [],
                rejection_reason: item.rejection_reason || original.rejection_reason || null,
                faces_detected: item.faces_detected || original.faces_detected || 0
            });
        })
        .filter(item => item && item.media_id)
        .filter(item => !isBadFavouriteMediaStatus(item.status || item.moderation_status))
        .filter(item =>
            canShowUrl(item.status) ||
            canShowUrl(item.content_rating) ||
            canShowUrl(item.moderation_status)
        )
        .slice(-MAX_FAVOURITE_MEDIA);
}

function getFreshSignedCreatorImageUrlFromUser(userData, type) {
    const isProfile = type === 'profile';

    const dbUrl = isProfile
        ? userData.profile_image
        : userData.background_image;

    const mediaId = isProfile
        ? userData.profile_image_media_id
        : userData.background_image_media_id;

    const status = normalizeStatus(
        isProfile
            ? userData.profile_image_status
            : userData.background_image_status,
        'PENDING'
    );

    const contentRating = normalizeStatus(
        isProfile
            ? userData.profile_content_rating
            : userData.background_content_rating,
        status
    );

    const viewable = canShowUrl(status) || canShowUrl(contentRating);

    if (!viewable) return null;

    // 1. DB me base URL hai:
    // https://fnties-cdn.b-cdn.net/images/img_xxx.webp
    if (dbUrl && /^https?:\/\//i.test(String(dbUrl))) {
        return addTokenToUrl(dbUrl);
    }

    // 2. DB me galti se media_id save ho gaya:
    // img_xxx
    const finalMediaId =
        mediaId ||
        extractMediaIdFromValue(dbUrl);

    if (finalMediaId && String(finalMediaId).startsWith('img_')) {
        return getSecureImageUrl(`images/${finalMediaId}.webp`);
    }

    return null;
}

function buildCreatorResponseUser(userInstance, {
    enrichedProfile,
    enrichedBackground,
    enrichedFavPics
}) {
    const userData = userInstance.dataValues || userInstance;

    const freshProfileUrl = getFreshSignedCreatorImageUrlFromUser(userData, 'profile');
    const freshBackgroundUrl = getFreshSignedCreatorImageUrlFromUser(userData, 'background');

    return {
        ...userData,

        // ✅ Frontend old fields: always fresh signed URL
        profile_image: freshProfileUrl,
        background_image: freshBackgroundUrl,

        // ✅ Full moderation objects
        profile_image_media: userData.profile_image_media_id
            ? {
                ...(enrichedProfile || {}),
                media_id: userData.profile_image_media_id,
                type: 'image',
                status: userData.profile_image_status || enrichedProfile?.status || 'PENDING',
                moderation_status: userData.profile_image_status || enrichedProfile?.moderation_status || 'PENDING',
                content_rating: userData.profile_content_rating || enrichedProfile?.content_rating || null,
                url: freshProfileUrl,
                preview_url: freshProfileUrl,
                moderation_tags: enrichedProfile?.moderation_tags || [],
                rejection_reason: enrichedProfile?.rejection_reason || null,
                faces_detected: enrichedProfile?.faces_detected || 0
            }
            : null,

        background_image_media: userData.background_image_media_id
            ? {
                ...(enrichedBackground || {}),
                media_id: userData.background_image_media_id,
                type: 'image',
                status: userData.background_image_status || enrichedBackground?.status || 'PENDING',
                moderation_status: userData.background_image_status || enrichedBackground?.moderation_status || 'PENDING',
                content_rating: userData.background_content_rating || enrichedBackground?.content_rating || null,
                url: freshBackgroundUrl,
                preview_url: freshBackgroundUrl,
                moderation_tags: enrichedBackground?.moderation_tags || [],
                rejection_reason: enrichedBackground?.rejection_reason || null,
                faces_detected: enrichedBackground?.faces_detected || 0
            }
            : null,

        // ✅ Favourite pics unchanged
        favourite_Pics: enrichedFavPics || []
    };
}
// ============================================================
// ✅ MAKE CREATOR
// ============================================================
const makeCreator = async (req, res) => {
    try {
        const userId = req.decodedToken.user_id;

        const user = await User.findOne({
            where: { id: userId }
        });

        if (!user) {
            return res.status(400).json({
                error: 'User not found'
            });
        }

        if (user.is_creator) {
            const creatorProfile = await ensureCreatorProfile(userId);

            return res.status(200).json({
                message: 'User is already a creator',
                creator_status: creatorProfile.creator_status || 'new'
            });
        }

        await user.update({
            is_creator: true
        });

        const creatorProfile = await ensureCreatorProfile(userId, {
            creator_status: 'new'
        });

        // ✅ Affiliate referral activation — user creator ban gaya
        try {
            await emitReferralActivated(userId);
        } catch (webhookError) {
            console.warn('⚠️ referral.activated webhook queue failed:', webhookError.message);
        }

        return res.status(200).json({
            message: 'User is now a creator',
            creator_status: creatorProfile.creator_status || 'new'
        });

    } catch (error) {
        console.error('❌ makeCreator Error:', error);

        return res.status(500).json({
            error: 'Error making user a creator',
            details: error.message
        });
    }
};

// ============================================================
// ✅ ADD / UPDATE CREATOR DATA
// ============================================================
const addCreatorData = async (req, res) => {
    try {
        const userId = req.decodedToken.user_id;

        const user = await User.findOne({
            where: {
                id: userId,
                is_creator: true
            }
        });

        if (!user) {
            return res.status(400).json({
                error: 'User is not a creator'
            });
        }

        // ✅ Creator business profile ensure karo
        // Is table mein creator_status save hota hai: new / student / established / premium
        // Creator khud yahan se status update nahi karega. Status admin/business side se update hoga.
        const creatorProfile = await ensureCreatorProfile(userId);

        const username = user.username || user.nickName || `creator_${userId}`;
        const updateData = {};

        // ── Profile Image ──────────────────────────────
        if (req.files?.profile_image?.[0]) {
            const [entry] = await uploadFiles(
                [req.files.profile_image[0]],
                {
                    context: 'CREATOR',
                    uploaderUsername: username,
                    coPerformers: [],
                    attestedSolo: true,
                    isPaidContent: false
                }
            );

            // DB me token/signed URL save nahi karni.
            // Webhook approve ke baad profile_image me base URL save karega.
            updateData.profile_image = null;
            updateData.profile_image_media_id = entry.media_id;
            updateData.profile_image_status = 'PENDING';

            console.log(`📸 Profile image queued: ${entry.media_id}`);
        }

        // ── Background Image ───────────────────────────
        if (req.files?.background_image?.[0]) {
            const [entry] = await uploadFiles(
                [req.files.background_image[0]],
                {
                    context: 'CREATOR',
                    uploaderUsername: username,
                    coPerformers: [],
                    attestedSolo: true,
                    isPaidContent: false
                }
            );

            // DB me token/signed URL save nahi karni.
            // Webhook approve ke baad background_image me base URL save karega.
            updateData.background_image = null;
            updateData.background_image_media_id = entry.media_id;
            updateData.background_image_status = 'PENDING';

            console.log(`🖼️ Background image queued: ${entry.media_id}`);
        }

        // ── Favourite Pics ─────────────────────────────
        // Final visible total max = 5 (image + video combined).
        // Pending/failed video old approved images ko delete nahi karegi.
        const favouriteFiles = req.files?.files || [];

        if (favouriteFiles.length > MAX_FAVOURITE_MEDIA) {
            return res.status(400).json({
                status: 'error',
                code: 'FAVOURITE_MEDIA_LIMIT_EXCEEDED',
                message: 'Favourite Pics can contain a maximum of 5 images/videos.',
                max: MAX_FAVOURITE_MEDIA,
                incoming: favouriteFiles.length
            });
        }

        if (favouriteFiles.length > 0) {
            const favouriteVideoTiming = getFavouriteVideoTiming(req.body);

            const entries = await uploadFiles(
                favouriteFiles,
                {
                    context: 'CREATOR',
                    uploaderUsername: username,
                    coPerformers: [],
                    attestedSolo: true,
                    isPaidContent: false,

                    // Backend-only fix:
                    // PostController wali video timing support yahan bhi pass karo.
                    // Agar frontend duration na bheje to worker.py ffprobe se real duration detect karega.
                    durationS: favouriteVideoTiming.durationS,
                    hasPreview: favouriteVideoTiming.hasPreview,
                    previewStart: favouriteVideoTiming.previewStart,
                    previewEnd: favouriteVideoTiming.previewEnd
                }
            );

            const existing = trimFavouritePicsForStorage(
                parseOrArray(user.favourite_Pics) || []
            );

            const newItems = entries.map(entry => ({
                media_id: entry.media_id,
                type: entry.type || 'image',
                bunny_video_id: entry.bunny_video_id || null,
                status: entry.status || 'PENDING',
                context: 'CREATOR',
                duration_s: entry.duration_s || favouriteVideoTiming.durationS || null,
                has_preview: !!entry.has_preview,

                // DB me signed/token URL save nahi karni.
                url: null,
                preview_url: null,

                moderation_tags: [],
                rejection_reason: null,
                faces_detected: 0
            }));

            // Important:
            // Pending media ko add karo, lekin old approved images abhi delete mat karo.
            // Agar video approve hogi to response/display layer max 5 maintain karegi.
            // Agar video fail hogi to failed video hide/remove hogi aur old images safe rahengi.
            const finalFavouritePics = [
                ...existing,
                ...newItems
            ];

            updateData.favourite_Pics = JSON.stringify(finalFavouritePics);

            console.log(
                `📁 Favourite pics updated | existing=${existing.length} new=${newItems.length} stored=${finalFavouritePics.length}`
            );
        }

        // ── Text Fields ────────────────────────────────
        const textFields = [
            'nickName',
            'description',
            'primary_Categories',
            'secondary_Categories',
            'content_preferences',
            'instagram',
            'twitter',
            'amazon',
            'Gender',
            'ethnicity',
            'age',
            'booty_size',
            'body_type',
            'eye_color',
            'hair_color',
            'Height',
            'Weight',
            'location',
            'Tatoos'
        ];

        for (const field of textFields) {
            if (req.body[field] !== undefined) {
                updateData[field] = req.body[field];
            }
        }

        if (req.body.tags !== undefined) {
            updateData.tags = JSON.stringify(parseOrArray(req.body.tags));
        }

        // ── Save to MySQL ──────────────────────────────
        await user.update(updateData);

        const updatedUser = await User.findOne({
            where: { id: userId }
        });

        // Fresh creator profile read karo, future status updates ke liye safe
        const updatedCreatorProfile = await ensureCreatorProfile(userId);

        // ── Enrich Media for Response ──────────────────
        const enrichedProfile = await buildCreatorMedia({
            mediaId: updatedUser.profile_image_media_id,
            dbUrl: updatedUser.profile_image,
            status: updatedUser.profile_image_status,
            contentRating: updatedUser.profile_content_rating
        });

        const enrichedBackground = await buildCreatorMedia({
            mediaId: updatedUser.background_image_media_id,
            dbUrl: updatedUser.background_image,
            status: updatedUser.background_image_status,
            contentRating: updatedUser.background_content_rating
        });

        const enrichedFavPics = await buildFavouritePics(updatedUser.favourite_Pics);

        res.set('Cache-Control', 'no-store');

        return res.status(200).json({
            status: 'success',
            message: 'Creator data updated. Media is under moderation.',
            userData: {
                ...buildCreatorResponseUser(updatedUser, {
                    enrichedProfile,
                    enrichedBackground,
                    enrichedFavPics
                }),
                creator_status: updatedCreatorProfile.creator_status || creatorProfile.creator_status || 'new'
            }
        });

    } catch (error) {
        console.error('❌ addCreatorData Error:', error);

        return res.status(500).json({
            error: error.message,
            details: error.stack
        });
    }
};

// ============================================================
// ✅ GET CREATOR PROFILE
// ============================================================
const getAllCreator = async (req, res) => {
    try {
        const userId = req.params.id || req.decodedToken.user_id;

        const user = await User.findOne({
            where: {
                id: userId,
                is_creator: true
            }
        });

        if (!user) {
            return res.status(404).json({
                error: 'Creator not found'
            });
        }

        const creatorProfile = await ensureCreatorProfile(userId);

        const enrichedFavPics = await buildFavouritePics(user.favourite_Pics);

        const enrichedProfile = await buildCreatorMedia({
            mediaId: user.profile_image_media_id,
            dbUrl: user.profile_image,
            status: user.profile_image_status,
            contentRating: user.profile_content_rating
        });

        const enrichedBackground = await buildCreatorMedia({
            mediaId: user.background_image_media_id,
            dbUrl: user.background_image,
            status: user.background_image_status,
            contentRating: user.background_content_rating
        });

        res.set('Cache-Control', 'no-store');

        return res.status(200).json({
            status: 'success',
            userData: {
                ...buildCreatorResponseUser(user, {
                    enrichedProfile,
                    enrichedBackground,
                    enrichedFavPics
                }),
                creator_status: creatorProfile.creator_status || 'new'
            }
        });

    } catch (error) {
        console.error('❌ getCreatorProfile Error:', error);

        return res.status(500).json({
            error: 'Error fetching creator profile',
            details: error.message
        });
    }
};




async function isBunnyVideoReady(bunnyVideoId) {
    if (!bunnyVideoId) return false;

    try {
        const response = await axios.get(
            `https://video.bunnycdn.com/library/${process.env.BUNNY_STREAM_LIBRARY_ID}/videos/${bunnyVideoId}`,
            {
                headers: {
                    AccessKey: process.env.BUNNY_STREAM_API_KEY,
                    accept: 'application/json'
                },
                timeout: 8000
            }
        );

        // Bunny Stream status:
        // 0 = created
        // 1 = uploaded
        // 2 = processing
        // 3 = transcoding
        // 4 = finished / ready
        // 5 = error
        // 6 = upload failed
        return Number(response.data?.status) === 4;
    } catch (error) {
        console.warn(
            `⚠️ Bunny video readiness check failed for ${bunnyVideoId}:`,
            error.response?.data || error.message
        );

        return false;
    }
}

async function getSafeFavouriteMediaUrl(item) {
    if (!item) return null;

    const playableStatuses = new Set([
        'SAFE',
        'SUGGESTIVE',
        'EXPLICIT',
        'APPROVED',
        'COMPLETED'
    ]);

    const status = normalizeStatus(
        item.status ||
        item.moderation_status ||
        'PENDING'
    );

    if (!playableStatuses.has(status)) {
        return null;
    }

    const type = String(item.type || '').toLowerCase();

    if (type === 'video') {
        if (!item.bunny_video_id) {
            return null;
        }

        const bunnyReady = await isBunnyVideoReady(item.bunny_video_id);

        if (!bunnyReady) {
            console.log(
                `⏳ Favourite video not ready yet, hiding from response: ${item.media_id} / ${item.bunny_video_id}`
            );

            return null;
        }

        return getSecureStreamUrl(item.bunny_video_id);
    }

    return item.url || null;
}

// ============================================================
// ✅ GET CREATOR FAVOURITE MEDIA URLS ONLY
//    - Sirf favourite_Pics
//    - Image + Video
//    - Max 5
//    - Failed / processing media ka broken URL expose nahi hota
// ============================================================
const getCreatorFavouritePics = async (req, res) => {
    try {
        const creatorId = Number(req.params.creatorId);

        if (!creatorId) {
            return res.status(400).json({
                status: 'error',
                message: 'Valid creatorId is required'
            });
        }

        const creator = await User.findOne({
            where: {
                id: creatorId,
                is_creator: true
            },
            attributes: [
                'id',
                'favourite_Pics'
            ]
        });

        if (!creator) {
            return res.status(404).json({
                status: 'error',
                message: 'Creator not found'
            });
        }

        const rawFavouritePics =
            parseOrArray(creator.favourite_Pics) || [];

        if (!rawFavouritePics.length) {
            res.set('Cache-Control', 'no-store');
            return res.status(200).json([]);
        }

        const favouriteMedia = rawFavouritePics
            .filter(item => item && item.media_id);

        const enrichedMedia = await enrichMediaList(favouriteMedia);

        // Important:
        // Failed / processing videos ko URL nahi milega.
        // Pehle full list enrich karo, phir sirf playable URLs se last 5 return karo.
        // Is se pending/failed video old approved image ko response se displace nahi karegi.
        const urls = (
            await Promise.all(
                (enrichedMedia || []).map(item => getSafeFavouriteMediaUrl(item))
            )
        )
            .filter(Boolean)
            .slice(-MAX_FAVOURITE_MEDIA);

        res.set('Cache-Control', 'no-store');

        return res.status(200).json(urls);

    } catch (error) {
        console.error(
            '❌ getCreatorFavouritePics Error:',
            error
        );

        return res.status(500).json({
            status: 'error',
            message: 'Error fetching creator favourite pics',
            details: error.message
        });
    }
};


// ============================================================
// ✅ RETRY FAILED CREATOR FAVOURITE VIDEO
//    Current creator sirf apni failed favourite video retry kar sakta hai.
// ============================================================
const retryCreatorFavouriteVideo = async (req, res) => {
    try {
        const userId = req.decodedToken.user_id;
        const mediaId = String(req.params.mediaId || '').trim();

        if (!mediaId || !mediaId.startsWith('vid_')) {
            return res.status(400).json({
                status: 'error',
                message: 'Valid video mediaId is required'
            });
        }

        const creator = await User.findOne({
            where: {
                id: userId,
                is_creator: true
            }
        });

        if (!creator) {
            return res.status(404).json({
                status: 'error',
                message: 'Creator not found'
            });
        }

        const favouritePics =
            parseOrArray(creator.favourite_Pics) || [];

        const favouriteVideo = favouritePics.find(
            item =>
                item &&
                item.media_id === mediaId &&
                String(item.type || '').toLowerCase() === 'video'
        );

        if (!favouriteVideo) {
            return res.status(404).json({
                status: 'error',
                message: 'Favourite video not found for this creator'
            });
        }

        const [mediaState] = await enrichMediaList([
            {
                media_id: mediaId,
                type: 'video'
            }
        ]);

        const currentStatus = normalizeStatus(
            mediaState?.status ||
            favouriteVideo.status ||
            'PENDING'
        );

        if (!['FAILED', 'ERROR'].includes(currentStatus)) {
            return res.status(409).json({
                status: 'error',
                code: 'VIDEO_NOT_FAILED',
                message: 'Only failed favourite videos can be retried.',
                current_status: currentStatus
            });
        }

        const newBunnyVideoId = await requeueAsset(
            mediaId,
            {
                ai_error_override: false
            }
        );

        const updatedFavouritePics = favouritePics.map(item => {
            if (!item || item.media_id !== mediaId) {
                return item;
            }

            return {
                ...item,
                type: 'video',
                bunny_video_id: newBunnyVideoId || null,
                status: 'PENDING',
                url: null,
                preview_url: null,
                moderation_tags: [],
                rejection_reason: null
            };
        });

        await creator.update({
            favourite_Pics: JSON.stringify(
                updatedFavouritePics
            )
        });

        res.set('Cache-Control', 'no-store');

        return res.status(200).json({
            status: 'success',
            message: 'Favourite video sent for reprocessing.',
            media_id: mediaId,
            bunny_video_id: newBunnyVideoId,
            processing_status: 'PROCESSING'
        });

    } catch (error) {
        console.error(
            '❌ retryCreatorFavouriteVideo Error:',
            error
        );

        return res.status(500).json({
            status: 'error',
            message: 'Failed to retry favourite video',
            details: error.message
        });
    }
};


// ============================================================
// ✅ UPDATE CREATOR STATUS
//    Use admin/trusted route only. Creator should NOT update this from profile form.
// ============================================================
const updateCreatorStatus = async (req, res) => {
    try {
        const targetUserId = Number(req.params.userId || req.body.userId);
        const nextStatus = normalizeCreatorStatus(req.body.creator_status);

        if (!targetUserId) {
            return res.status(400).json({
                ok: false,
                message: 'userId is required'
            });
        }

        // Optional extra secret for production safety.
        // If CREATOR_STATUS_UPDATE_SECRET is set, request must send:
        // x-creator-status-secret: <secret>
        const requiredSecret = process.env.CREATOR_STATUS_UPDATE_SECRET;
        if (requiredSecret) {
            const providedSecret = req.headers['x-creator-status-secret'];
            if (providedSecret !== requiredSecret) {
                return res.status(403).json({
                    ok: false,
                    message: 'Forbidden: invalid creator status secret'
                });
            }
        }

        const user = await User.findOne({
            where: {
                id: targetUserId,
                is_creator: true
            }
        });

        if (!user) {
            return res.status(404).json({
                ok: false,
                message: 'Creator not found'
            });
        }

        const creatorProfile = await ensureCreatorProfile(targetUserId);

        await creatorProfile.update({
            creator_status: nextStatus
        });

        return res.status(200).json({
            ok: true,
            message: 'Creator status updated successfully',
            userId: targetUserId,
            creator_status: nextStatus
        });

    } catch (error) {
        console.error('❌ updateCreatorStatus Error:', error);

        return res.status(500).json({
            ok: false,
            message: error.message
        });
    }
};

module.exports = {
    makeCreator,
    addCreatorData,
    getAllCreator,
    getCreatorFavouritePics,
    retryCreatorFavouriteVideo,
    updateCreatorStatus
};